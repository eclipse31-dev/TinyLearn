<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('assignments', function (Blueprint $table) {
    $table->id();
    $table->foreignId('module_id')->constrained('modules')->onDelete('cascade');
    $table->string('title');
    $table->text('description')->nullable();
    $table->date('due_date');
    $table->enum('status', ['draft', 'published', 'closed'])->default('draft');
    $table->foreignId('created_by')->constrained('users')->onDelete('set null');
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assignments');
    }
};
