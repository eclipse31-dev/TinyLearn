<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Rename the table from 'assignments' to 'assessments'
        Schema::rename('assignments', 'assessments');

        // 2. Modify the table structure
        Schema::table('assessments', function (Blueprint $table) {
            // Rename existing primary key if necessary (Laravel usually uses 'id')
            $table->renameColumn('id', 'assessment_ID');

            // Add new Foreign Key columns
            $table->unsignedBigInteger('user_id')->after('assessment_ID');
            $table->unsignedBigInteger('module_ID')->after('user_id');
            $table->unsignedBigInteger('submission_id')->nullable()->after('module_ID');
            $table->unsignedBigInteger('attachment_ID')->nullable()->after('submission_id');

            // Add status and points
            $table->integer('total_points')->default(0)->after('attachment_ID');
            $table->enum('status', ['draft', 'published', 'closed'])->default('draft')->after('total_points');

            // Handle the 'created_by' logic
            $table->unsignedBigInteger('created_by')->after('due_date');

            // If 'course_id' and 'title' from your old table are no longer needed, 
            // you can drop them here:
            // $table->dropColumn(['course_id', 'title']);
        });
    }

    public function down(): void
    {
        // Reverse the changes
        Schema::table('assessments', function (Blueprint $table) {
            $table->renameColumn('assessment_ID', 'id');
            $table->dropColumn(['user_id', 'module_ID', 'submission_id', 'attachment_ID', 'total_points', 'status', 'created_by']);
        });

        Schema::rename('assessments', 'assignments');
    }
};