<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->string('header_image_url')->nullable()->after('description');
            $table->string('instructor_avatar_url')->nullable()->after('instructor');
            $table->text('long_description')->nullable()->after('header_image_url');
            $table->integer('students_enrolled')->default(0)->after('duration_minutes');
            $table->decimal('rating', 3, 1)->default(0)->after('students_enrolled');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->dropColumn(['header_image_url', 'instructor_avatar_url', 'long_description', 'students_enrolled', 'rating']);
        });
    }
};
