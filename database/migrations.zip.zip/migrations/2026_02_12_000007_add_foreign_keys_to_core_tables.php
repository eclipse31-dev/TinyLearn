<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Add attachment_id and created_by to announcements
        Schema::table('announcements', function (Blueprint $table) {
            if (!Schema::hasColumn('announcements', 'created_by')) {
                $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
            }
            if (!Schema::hasColumn('announcements', 'attachment_id')) {
                $table->foreignId('attachment_id')->nullable()->constrained('attachments')->onDelete('set null');
            }
        });

        // Add attachment_id to resources
        Schema::table('resources', function (Blueprint $table) {
            if (!Schema::hasColumn('resources', 'attachment_id')) {
                $table->foreignId('attachment_id')->nullable()->constrained('attachments')->onDelete('set null');
            }
        });

        // Add attachment_id to submissions
        Schema::table('submissions', function (Blueprint $table) {
            if (!Schema::hasColumn('submissions', 'attachment_id')) {
                $table->foreignId('attachment_id')->nullable()->constrained('attachments')->onDelete('set null');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('announcements', function (Blueprint $table) {
            if (Schema::hasColumn('announcements', 'created_by')) {
                $table->dropForeign(['created_by']);
                $table->dropColumn('created_by');
            }
            if (Schema::hasColumn('announcements', 'attachment_id')) {
                $table->dropForeign(['attachment_id']);
                $table->dropColumn('attachment_id');
            }
        });

        Schema::table('resources', function (Blueprint $table) {
            if (Schema::hasColumn('resources', 'attachment_id')) {
                $table->dropForeign(['attachment_id']);
                $table->dropColumn('attachment_id');
            }
        });

        Schema::table('submissions', function (Blueprint $table) {
            if (Schema::hasColumn('submissions', 'attachment_id')) {
                $table->dropForeign(['attachment_id']);
                $table->dropColumn('attachment_id');
            }
        });
    }
};
