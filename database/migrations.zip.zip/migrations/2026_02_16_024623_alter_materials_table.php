<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('materials', function (Blueprint $table) {
    $table->dropColumn(['course_id', 'type', 'url', 'file_path', 'file_name', 'file_size', 'mime_type']);
    $table->renameColumn('description', 'content');
    $table->unsignedBigInteger('attachment_id')->nullable()->after('content');

    $table->foreign('attachment_id')->references('id')->on('attachments')->onDelete('set null');
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('materials', function (Blueprint $table) {
            //
        });
    }
};
