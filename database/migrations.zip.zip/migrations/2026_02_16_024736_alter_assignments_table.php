<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('assignments', function (Blueprint $table) {
            // Add module_ID FK
            $table->unsignedBigInteger('module_ID')->after('id');
            // Add created_by FK
            $table->unsignedBigInteger('created_by')->after('due_date');
            // Add status column
            $table->enum('status', ['draft', 'published', 'closed'])->default('draft')->after('description');

            // Set foreign keys
            $table->foreign('module_ID')->references('module_ID')->on('modules')->onDelete('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('assignments', function (Blueprint $table) {
            // Drop foreign keys first
            $table->dropForeign(['module_ID']);
            $table->dropForeign(['created_by']);
            // Drop columns
            $table->dropColumn(['module_ID', 'created_by', 'status']);
        });
    }
};