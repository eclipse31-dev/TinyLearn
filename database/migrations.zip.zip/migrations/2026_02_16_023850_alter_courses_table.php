<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            // Drop unnecessary columns
            $table->dropColumn([
                'header_image_url',
                'long_description',
                'instructor_avatar_url',
                'duration_minutes',
                'day_of_week',
                'start_time',
                'end_time',
                'location',
                'has_schedule',
            ]);

            // Alter instructor column to unsignedBigInteger
            $table->unsignedBigInteger('instructor')->change();

            // Add foreign key
            $table->foreign('instructor')
                  ->references('id')
                  ->on('users')
                  ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            // Re-add dropped columns
            $table->string('header_image_url')->nullable();
            $table->text('long_description')->nullable();
            $table->string('instructor_avatar_url')->nullable();
            $table->integer('duration_minutes')->nullable();
            $table->enum('day_of_week', ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'])->nullable();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->string('location')->nullable();
            $table->tinyInteger('has_schedule')->default(0);

            // Drop foreign key
            $table->dropForeign(['instructor']);
        });
    }
};