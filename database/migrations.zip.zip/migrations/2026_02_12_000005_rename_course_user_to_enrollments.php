<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Create new enrollments table
        Schema::create('enrollments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('course_id')->constrained('courses')->onDelete('cascade');
            $table->enum('status', ['active', 'dropped', 'completed'])->default('active');
            $table->timestamp('enrolled_at')->useCurrent();
            $table->timestamps();
            
            $table->unique(['user_id', 'course_id']);
        });

        // Migrate data from course_user to enrollments
        if (Schema::hasTable('course_user')) {
            DB::statement('INSERT INTO enrollments (user_id, course_id, status, enrolled_at, created_at, updated_at) 
                          SELECT user_id, course_id, "active", enrolled_at, created_at, updated_at FROM course_user');
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('enrollments');
    }
};
